
import colours

SHOW_POS = True
SHOW_COLOUR = True
COLOUR = colours.WHITE
VERBOSE = False
