:- module(version,[version/1]).
version('boxer 590:592M (unix build on 18 April 2008, 13:30:02)').
