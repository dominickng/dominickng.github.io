:- module(version,[version/1]).
version('boxer v1.00 (unix build on 21 February 2013, 05:17:12)').
