namespace NLP {
  const char *VERSION = "v1.00";

  const char *BUILD = "(unix build on 21 February 2013, 05:17:12)";
}
